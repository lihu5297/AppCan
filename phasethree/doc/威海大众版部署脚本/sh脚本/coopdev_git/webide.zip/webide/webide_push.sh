# $1 repo path
# $2 branch name
cd $1
git push --set-upstream origin $2
